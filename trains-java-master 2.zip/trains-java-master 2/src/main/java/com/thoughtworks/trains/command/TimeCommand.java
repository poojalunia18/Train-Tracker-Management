package com.thoughtworks.trains.command;

import java.io.PrintStream;

public class TimeCommand extends DurationCommand {


	    public TimeCommand(String commandLine, PrintStream outputStream) {
	        super(commandLine, outputStream);
	    }

}
